import express from 'express';
import { authMiddleware } from '../middleware/auth.js';

const router = express.Router();

// A robust set of English stop words + common resume filler words to exclude
export const STOP_WORDS = new Set([
  'a', 'about', 'above', 'after', 'again', 'against', 'all', 'am', 'an', 'and', 'any', 'are', 'arent', 'as', 'at',
  'be', 'because', 'been', 'before', 'being', 'below', 'between', 'both', 'but', 'by', 'cant', 'cannot', 'could',
  'couldnt', 'did', 'didnt', 'do', 'does', 'doesnt', 'doing', 'dont', 'down', 'during', 'each', 'few', 'for',
  'from', 'further', 'had', 'hadnt', 'has', 'hasnt', 'have', 'havent', 'having', 'he', 'hed', 'hell', 'hes',
  'her', 'here', 'heres', 'hers', 'herself', 'him', 'himself', 'his', 'how', 'hows', 'i', 'id', 'ill', 'im',
  'ive', 'if', 'in', 'into', 'is', 'isnt', 'it', 'its', 'itself', 'lets', 'me', 'more', 'most', 'mustnt', 'my',
  'myself', 'no', 'nor', 'not', 'of', 'off', 'on', 'once', 'only', 'or', 'other', 'ought', 'our', 'ours',
  'ourselves', 'out', 'over', 'own', 'same', 'shant', 'she', 'shed', 'shell', 'shes', 'should', 'shouldnt',
  'so', 'some', 'such', 'than', 'that', 'thats', 'the', 'their', 'theirs', 'them', 'themselves', 'then',
  'there', 'theres', 'these', 'they', 'theyd', 'theyll', 'theyre', 'theyve', 'this', 'those', 'through',
  'to', 'too', 'under', 'until', 'up', 'very', 'was', 'wasnt', 'we', 'wed', 'well', 'were', 'weve', 'werent',
  'what', 'whats', 'when', 'where', 'which', 'while', 'who', 'whom', 'why', 'with', 'wont', 'would', 'wouldnt',
  'you', 'youd', 'youll', 'youre', 'youve', 'your', 'yours', 'yourself', 'yourselves',
  // Common job description / filler words
  'experience', 'skills', 'work', 'job', 'ability', 'role', 'team', 'years', 'candidate', 'position',
  'requirements', 'duties', 'responsibilities', 'qualified', 'successful', 'ideal', 'key', 'strong',
  'preferred', 'required', 'minimum', 'plus', 'join', 'company', 'looking', 'description', 'opportunity',
  'support', 'build', 'develop', 'manage', 'help', 'design', 'lead', 'deliver', 'create', 'working'
]);

// Extracts the most frequent meaningful keywords from a job description.
// Shared by the ATS checker AND the resume generator so they stay perfectly in sync.
export const extractKeywords = (jobDescription, limit = 25) => {
  const jdClean = (jobDescription || '').toLowerCase().replace(/[^\w\s-]/g, ' ');
  const jdBits = jdClean.split(/\s+/);
  const freqMap = {};
  for (const word of jdBits) {
    const cleanWord = word.trim();
    if (cleanWord.length >= 2 && !STOP_WORDS.has(cleanWord) && isNaN(cleanWord)) {
      freqMap[cleanWord] = (freqMap[cleanWord] || 0) + 1;
    }
  }
  return Object.entries(freqMap)
    .sort((a, b) => b[1] - a[1])
    .map((entry) => entry[0])
    .slice(0, limit);
};

// POST /api/ats/check
router.post('/check', authMiddleware, (req, res) => {
  try {
    const { resumeText, jobDescription } = req.body;

    if (!resumeText || !jobDescription) {
      return res.status(400).json({ error: 'Please provide both the resume text and the job description.' });
    }

    // Extract the top keywords from the Job Description (shared with resume generation)
    const sortedKeywords = extractKeywords(jobDescription, 25);

    if (sortedKeywords.length === 0) {
      return res.json({
        score: 0,
        matched: [],
        missing: [],
        verdict: 'The job description seems to contain no identifiable skills or keywords. Please add more details to the job description.',
      });
    }

    // 4. Check which keywords appear in the resume
    const resumeLower = resumeText.toLowerCase();
    const matched = [];
    const missing = [];

    for (const keyword of sortedKeywords) {
      // Use regex to look for word boundary or simple substring.
      // A simple regex word boundary or simple include. 
      // Include is safer for composite terms or partial matches (e.g., "react" matching "React.js").
      // Let's check if resume includes the keyword.
      if (resumeLower.includes(keyword)) {
        matched.push(keyword);
      } else {
        missing.push(keyword);
      }
    }

    // 5. Calculate ATS alignment score
    const score = Math.round((matched.length / sortedKeywords.length) * 100);

    // 6. Generate a helpful plain-English verdict
    let verdict = '';
    if (score >= 80) {
      verdict = 'Excellent! Your resume is highly aligned with this job description. It contains a strong percentage of core keywords.';
    } else if (score >= 50) {
      verdict = 'Good alignment, but can be improved. Consider editing your resume/profile to naturally integrate some of the missing keywords below.';
    } else {
      verdict = 'Weak alignment. Your resume is missing more than half of the critical keywords from this job description. We highly recommend modifying your profile and regenerating the resume.';
    }

    return res.json({
      score,
      matched,
      missing,
      verdict,
    });
  } catch (error) {
    return res.status(500).json({ error: 'An error occurred during the ATS analysis. Please try again.' });
  }
});

export default router;