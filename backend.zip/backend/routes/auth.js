import express from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import User from '../models/User.js';

const router = express.Router();

// POST /api/auth/register
router.post('/register', async (req, res) => {
  try {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Please fill in all fields (name, email, password).' });
    }

    const cleanEmail = email.toLowerCase().trim();
    
    // Simple email regex validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(cleanEmail)) {
      return res.status(400).json({ error: 'Please enter a valid email address.' });
    }

    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters long.' });
    }

    // Check if user already exists
    const existingUser = await User.findOne({ email: cleanEmail });
    if (existingUser) {
      return res.status(400).json({ error: 'An account with this email already exists.' });
    }

    // Hash the password
    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(password, salt);

    // Create and save user
    const newUser = new User({
      name: name.trim(),
      email: cleanEmail,
      passwordHash,
    });
    await newUser.save();

    // Generate JWT token (valid for 7 days)
    const secret = process.env.JWT_SECRET || 'fallback_secret_for_development_only';
    const token = jwt.sign({ id: newUser._id }, secret, { expiresIn: '7d' });

    return res.status(201).json({
      token,
      user: {
        id: newUser._id,
        name: newUser.name,
        email: newUser.email,
      },
    });
  } catch (error) {
    return res.status(500).json({ error: 'Failed to register. Please try again later.' });
  }
});

// POST /api/auth/login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Please enter both email and password.' });
    }

    const cleanEmail = email.toLowerCase().trim();
    const user = await User.findOne({ email: cleanEmail });

    const loginFailMessage = "Invalid email or password. If you don't have an account yet, please register first.";

    if (!user) {
      return res.status(401).json({ error: loginFailMessage });
    }

    const isMatch = await bcrypt.compare(password, user.passwordHash);
    if (!isMatch) {
      return res.status(401).json({ error: loginFailMessage });
    }

    // Generate JWT token (valid for 7 days)
    const secret = process.env.JWT_SECRET || 'fallback_secret_for_development_only';
    const token = jwt.sign({ id: user._id }, secret, { expiresIn: '7d' });

    return res.json({
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
      },
    });
  } catch (error) {
    return res.status(500).json({ error: 'Failed to log in. Please try again later.' });
  }
});

export default router;
