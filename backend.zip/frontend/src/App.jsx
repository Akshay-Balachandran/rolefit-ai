import React, { useState, useEffect } from 'react';

// --- Markdown rendering for the formatted preview & PDF export ---
// Handles the format Gemini returns: # H1, ## H2, **bold**, and "* " bullet lists.
const renderInline = (text, keyPrefix) => {
  const parts = [];
  const regex = /\*\*(.+?)\*\*/g;
  let last = 0, match, i = 0;
  while ((match = regex.exec(text)) !== null) {
    if (match.index > last) parts.push(text.slice(last, match.index));
    parts.push(<strong key={`${keyPrefix}-b${i++}`}>{match[1]}</strong>);
    last = regex.lastIndex;
  }
  if (last < text.length) parts.push(text.slice(last));
  return parts;
};

const renderResume = (raw) => {
  const lines = (raw || '').split('\n');
  const blocks = [];
  let bullets = null;
  const flush = () => {
    if (bullets) {
      blocks.push(<ul key={`ul-${blocks.length}`}>{bullets}</ul>);
      bullets = null;
    }
  };
  lines.forEach((line, idx) => {
    const t = line.trim();
    if (/^\*\s+/.test(t)) {
      if (!bullets) bullets = [];
      bullets.push(<li key={`li-${idx}`}>{renderInline(t.replace(/^\*\s+/, ''), `li-${idx}`)}</li>);
    } else if (t.startsWith('## ')) {
      flush();
      blocks.push(<h2 key={`h2-${idx}`}>{renderInline(t.slice(3), `h2-${idx}`)}</h2>);
    } else if (t.startsWith('# ')) {
      flush();
      blocks.push(<h1 key={`h1-${idx}`}>{renderInline(t.slice(2), `h1-${idx}`)}</h1>);
    } else if (t === '') {
      flush();
    } else {
      flush();
      blocks.push(<p key={`p-${idx}`}>{renderInline(t, `p-${idx}`)}</p>);
    }
  });
  flush();
  return blocks;
};

function App() {
  // Authentication state
  const [token, setToken] = useState(localStorage.getItem('token') || '');
  const [user, setUser] = useState(() => {
    const savedUser = localStorage.getItem('user');
    try {
      return savedUser ? JSON.parse(savedUser) : null;
    } catch {
      return null;
    }
  });
  
  // Auth Form State
  const [isLoginMode, setIsLoginMode] = useState(true);
  const [authName, setAuthName] = useState('');
  const [authEmail, setAuthEmail] = useState('');
  const [authPassword, setAuthPassword] = useState('');

  // App Core State
  const [profileText, setProfileText] = useState('');
  const [jobDescription, setJobDescription] = useState('');
  const [resumeText, setResumeText] = useState('');
  const [tailoringNotes, setTailoringNotes] = useState([]);
  const [atsResult, setAtsResult] = useState({
    score: null,
    matched: [],
    missing: [],
    verdict: ''
  });
  
  // Saved resumes state
  const [savedResumes, setSavedResumes] = useState([]);
  const [selectedResumeId, setSelectedResumeId] = useState(null);
  const [saveTitle, setSaveTitle] = useState('');

  // Status/Loading States
  const [isGenerating, setIsGenerating] = useState(false);
  const [isExtracting, setIsExtracting] = useState(false);
  const [isAtsChecking, setIsAtsChecking] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isListLoading, setIsListLoading] = useState(false);
  
  // Feedback States
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Clear messages after a delay
  useEffect(() => {
    if (error) {
      const timer = setTimeout(() => setError(''), 8000);
      return () => clearTimeout(timer);
    }
  }, [error]);

  useEffect(() => {
    if (success) {
      const timer = setTimeout(() => setSuccess(''), 5000);
      return () => clearTimeout(timer);
    }
  }, [success]);

  // Load Saved Resumes list on login
  useEffect(() => {
    if (token) {
      fetchResumes();
    }
  }, [token]);

  // Helper for authenticated API headers
  const getAuthHeaders = (extraHeaders = {}) => {
    return {
      'Authorization': `Bearer ${token}`,
      ...extraHeaders
    };
  };

  // Centralized API response handler for 401s
  const handleApiResponse = async (response) => {
    if (response.status === 401) {
      // Clear credentials
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      setToken('');
      setUser(null);
      setSavedResumes([]);
      setError('Your session has expired. Please log in again.');
      throw new Error('Unauthorized');
    }
    
    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error || 'Request failed. Please try again.');
    }
    return data;
  };

  // Auth Operations
  const handleAuthSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    const url = isLoginMode ? '/api/auth/login' : '/api/auth/register';
    const payload = isLoginMode 
      ? { email: authEmail, password: authPassword }
      : { name: authName, email: authEmail, password: authPassword };

    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Authentication failed.');
      }

      // Store in state & localStorage
      localStorage.setItem('token', data.token);
      localStorage.setItem('user', JSON.stringify(data.user));
      setToken(data.token);
      setUser(data.user);
      
      // Reset fields
      setAuthName('');
      setAuthEmail('');
      setAuthPassword('');
      setSuccess(`Welcome back, ${data.user.name}!`);
    } catch (err) {
      setError(err.message || 'An error occurred during authentication.');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setToken('');
    setUser(null);
    setSavedResumes([]);
    setProfileText('');
    setJobDescription('');
    setResumeText('');
    setTailoringNotes([]);
    setAtsResult({ score: null, matched: [], missing: [], verdict: '' });
    setSelectedResumeId(null);
    setSuccess('Logged out successfully.');
  };

  // Fetch all saved resumes for the user
  const fetchResumes = async () => {
    setIsListLoading(true);
    try {
      const response = await fetch('/api/resume', {
        headers: getAuthHeaders()
      });
      const data = await handleApiResponse(response);
      setSavedResumes(data);
    } catch (err) {
      if (err.message !== 'Unauthorized') {
        setError('Could not load your saved resumes.');
      }
    } finally {
      setIsListLoading(false);
    }
  };

  // Load a single resume
  const handleLoadResume = async (id) => {
    setError('');
    setSuccess('');
    try {
      const response = await fetch(`/api/resume/${id}`, {
        headers: getAuthHeaders()
      });
      const data = await handleApiResponse(response);
      
      setProfileText(data.profile || '');
      setJobDescription(data.jobDescription || '');
      setResumeText(data.resumeText || '');
      setSelectedResumeId(data._id);
      
      // Preset ATS score preview from saved data
      setAtsResult({
        score: data.atsScore,
        matched: [],
        missing: [],
        verdict: `Saved Score: ${data.atsScore}%. Click "Check ATS Readiness" below to run a keyword assessment.`
      });
      setTailoringNotes([]);
      setSuccess(`Loaded resume: "${data.title}"`);
    } catch (err) {
      if (err.message !== 'Unauthorized') {
        setError('Failed to load the selected resume.');
      }
    }
  };

  // File Text Extraction Handler
  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setError('');
    setIsExtracting(true);

    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await fetch('/api/profile/extract', {
        method: 'POST',
        headers: getAuthHeaders(),
        body: formData
      });
      const data = await handleApiResponse(response);
      
      setProfileText(data.text);
      setSuccess('Successfully extracted text from document!');
    } catch (err) {
      if (err.message !== 'Unauthorized') {
        setError(err.message || 'Failed to extract text from the file.');
      }
    } finally {
      setIsExtracting(false);
      // Reset input value so same file can be uploaded again
      e.target.value = '';
    }
  };

  // Resume Tailoring Call
  const handleGenerateResume = async () => {
    if (!profileText || !jobDescription) return;
    
    setError('');
    setSuccess('');
    setIsGenerating(true);
    setResumeText('');
    setTailoringNotes([]);
    setAtsResult({ score: null, matched: [], missing: [], verdict: '' });

    try {
      const response = await fetch('/api/resume/generate', {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          profile: profileText,
          jobDescription: jobDescription
        })
      });
      const data = await handleApiResponse(response);

      setResumeText(data.resumeText);
      setTailoringNotes(data.tailoringNotes || []);
      setSuccess('Resume tailored successfully!');
    } catch (err) {
      if (err.message !== 'Unauthorized') {
        setError(err.message || 'An error occurred during resume tailoring.');
      }
    } finally {
      setIsGenerating(false);
    }
  };

  // Deterministic Keyword ATS Checker Call
  const handleAtsCheck = async () => {
    if (!resumeText || !jobDescription) return;

    setError('');
    setIsAtsChecking(true);

    try {
      const response = await fetch('/api/ats/check', {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          resumeText: resumeText,
          jobDescription: jobDescription
        })
      });
      const data = await handleApiResponse(response);

      setAtsResult({
        score: data.score,
        matched: data.matched,
        missing: data.missing,
        verdict: data.verdict
      });
      setSuccess('ATS analysis complete!');
    } catch (err) {
      if (err.message !== 'Unauthorized') {
        setError(err.message || 'Failed to check ATS keywords.');
      }
    } finally {
      setIsAtsChecking(false);
    }
  };

  // Save Resume handler
  const handleSaveResume = async () => {
    if (!resumeText) return;

    const finalTitle = saveTitle.trim() || 'Tailored Resume';
    
    setError('');
    setIsSaving(true);

    try {
      // If the user hasn't run an ATS check yet, run it now so the saved score is real (not 0)
      let scoreToSave = atsResult.score;
      if (scoreToSave === null && jobDescription) {
        try {
          const atsRes = await fetch('/api/ats/check', {
            method: 'POST',
            headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
            body: JSON.stringify({ resumeText, jobDescription })
          });
          const atsData = await handleApiResponse(atsRes);
          scoreToSave = atsData.score;
          setAtsResult({
            score: atsData.score,
            matched: atsData.matched,
            missing: atsData.missing,
            verdict: atsData.verdict
          });
        } catch (atsErr) {
          if (atsErr.message === 'Unauthorized') throw atsErr;
          scoreToSave = 0;
        }
      }

      const response = await fetch('/api/resume', {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          title: finalTitle,
          profile: profileText,
          jobDescription: jobDescription,
          resumeText: resumeText,
          atsScore: scoreToSave !== null ? scoreToSave : 0
        })
      });
      const data = await handleApiResponse(response);

      setSelectedResumeId(data._id);
      setSuccess(`Resume "${finalTitle}" saved successfully!`);
      setSaveTitle('');
      fetchResumes(); // refresh sidebar list
    } catch (err) {
      if (err.message !== 'Unauthorized') {
        setError(err.message || 'Failed to save resume.');
      }
    } finally {
      setIsSaving(false);
    }
  };

  // Export to PDF (Triggers print media stylesheets)
  const handleExportPdf = () => {
    if (!resumeText) return;
    setError('');
    setSuccess('Opening your print dialog — choose "Save as PDF" as the destination to export.');
    setTimeout(() => window.print(), 150);
  };

  // Helper score range color class
  const getScoreColorClass = (score) => {
    if (score === null) return '';
    if (score < 50) return 'low';
    if (score < 80) return 'medium';
    return '';
  };

  // RENDER AUTH PAGE IF NOT LOGGED IN
  if (!token) {
    return (
      <div className="auth-page">
        <div className="auth-card">
          <div className="auth-header">
            <div className="auth-logo">
              <div className="logo-mark">R</div>
            </div>
            <h1 className="auth-title">RoleFit <span>AI</span></h1>
            <p className="auth-subtitle">
              {isLoginMode 
                ? 'Sign in to access your tailored resumes' 
                : 'Create an account to start tailoring resumes'}
            </p>
          </div>

          {error && (
            <div className="error-banner">
              <span>⚠️</span> {error}
            </div>
          )}
          {success && (
            <div className="success-banner">
              {success}
            </div>
          )}

          <form onSubmit={handleAuthSubmit}>
            {!isLoginMode && (
              <div className="form-group">
                <label className="form-label">Full Name</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="John Doe"
                  value={authName}
                  onChange={(e) => setAuthName(e.target.value)}
                  required={!isLoginMode}
                />
              </div>
            )}

            <div className="form-group">
              <label className="form-label">Email Address</label>
              <input
                type="email"
                className="form-control"
                placeholder="name@domain.com"
                value={authEmail}
                onChange={(e) => setAuthEmail(e.target.value)}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">Password</label>
              <input
                type="password"
                className="form-control"
                placeholder="••••••••"
                value={authPassword}
                onChange={(e) => setAuthPassword(e.target.value)}
                required
              />
            </div>

            <button type="submit" className="btn btn-primary" style={{ marginTop: '1rem' }}>
              {isLoginMode ? 'Sign In' : 'Create Account'}
            </button>
          </form>

          <p className="auth-toggle-text">
            {isLoginMode ? "Don't have an account yet?" : "Already have an account?"}
            <button 
              type="button" 
              className="auth-link" 
              onClick={() => {
                setIsLoginMode(!isLoginMode);
                setError('');
                setSuccess('');
              }}
            >
              {isLoginMode ? 'Register' : 'Log In'}
            </button>
          </p>
        </div>
      </div>
    );
  }

  // RENDER APP MAIN PAGE IF LOGGED IN
  return (
    <>
      {/* Printable Area - Hidden on Screen, visible only in @media print */}
      <div className="printable-resume">
        <div className="printable-resume-content">{renderResume(resumeText)}</div>
      </div>

      {/* Screen Interface Wrapper */}
      <div className="app-container no-print">
        <header className="app-header">
          <div className="logo-container">
            <div className="logo-mark">R</div>
            <div className="logo-text">RoleFit <span>AI</span></div>
          </div>

          <div className="user-nav">
            <div className="user-info">
              Logged in as: <span className="user-name">{user?.name}</span>
            </div>
            <button onClick={handleLogout} className="btn btn-secondary" style={{ width: 'auto', padding: '0.5rem 1rem' }}>
              Log Out
            </button>
          </div>
        </header>

        {error && (
          <div className="error-banner" style={{ margin: '1.5rem 2rem 0' }}>
            <span>⚠️</span> {error}
          </div>
        )}
        {success && (
          <div className="success-banner" style={{ margin: '1.5rem 2rem 0' }}>
            {success}
          </div>
        )}

        <main className="main-layout">
          {/* LEFT SIDEBAR: SAVED RESUMES */}
          <aside className="sidebar">
            <div className="card">
              <h2 className="card-title">
                My Saved Resumes
                {isListLoading && <span style={{ fontSize: '0.8rem', color: 'var(--mint)' }}>Loading...</span>}
              </h2>
              
              <div className="resume-list">
                {savedResumes.length === 0 ? (
                  <div className="empty-state">
                    {isListLoading ? 'Retrieving records...' : 'No resumes saved yet. Generate one to get started!'}
                  </div>
                ) : (
                  savedResumes.map((resume) => (
                    <button
                      key={resume._id}
                      onClick={() => handleLoadResume(resume._id)}
                      className={`resume-item ${selectedResumeId === resume._id ? 'active' : ''}`}
                    >
                      <div className="resume-item-title">{resume.title}</div>
                      <div className="resume-item-meta">
                        <span>
                          {new Date(resume.updatedAt).toLocaleDateString(undefined, {
                            month: 'short',
                            day: 'numeric'
                          })}
                        </span>
                        <span className={`score-badge ${getScoreColorClass(resume.atsScore)}`}>
                          ATS: {resume.atsScore}%
                        </span>
                      </div>
                    </button>
                  ))
                )}
              </div>
            </div>
          </aside>

          {/* RIGHT WORKSPACE: GENERATOR & CHECKER */}
          <section className="workspace">
            {/* FILE EXTRACTION COMPONENT */}
            <div className="card">
              <h3 className="card-title" style={{ fontSize: '1rem', marginBottom: '0.75rem' }}>
                Upload an existing resume (PDF, Word, or text) — optional
              </h3>
              <div className={`file-upload-wrapper ${isExtracting ? 'uploading' : ''}`}>
                <input
                  type="file"
                  className="file-upload-input"
                  accept=".pdf,.docx,.txt"
                  onChange={handleFileUpload}
                  disabled={isExtracting}
                />
                <div className="file-upload-text">
                  {isExtracting ? (
                    <strong>Extracting text from your file... Please wait.</strong>
                  ) : (
                    <>
                      Drag and drop or <strong>click to upload</strong> a file (.pdf, .docx, .txt, max 5MB)
                    </>
                  )}
                </div>
              </div>
            </div>

            {/* TWO-COLUMN EDITORS */}
            <div className="two-col-editor">
              {/* PROFILE DETAILS */}
              <div className="card">
                <label className="form-label" style={{ fontWeight: '700', color: 'var(--text-primary)' }}>
                  Your Profile / Experience
                </label>
                <p style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', marginBottom: '0.75rem' }}>
                  Provide your work history, skills, achievements, and education. No sample data loaded.
                </p>
                <textarea
                  className="form-control"
                  style={{ minHeight: '300px' }}
                  placeholder="Paste your existing resume raw text, or write down your work experience (company, role, responsibilities), key skills, and credentials. The AI will use this raw details to align with the job description."
                  value={profileText}
                  onChange={(e) => setProfileText(e.target.value)}
                />
              </div>

              {/* TARGET JOB DESCRIPTION */}
              <div className="card">
                <label className="form-label" style={{ fontWeight: '700', color: 'var(--text-primary)' }}>
                  Target Job Description
                </label>
                <p style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', marginBottom: '0.75rem' }}>
                  Paste the full job description of the position you want to apply for.
                </p>
                <textarea
                  className="form-control"
                  style={{ minHeight: '300px' }}
                  placeholder="Paste the complete responsibilities, qualifications, and requirements from the job description here..."
                  value={jobDescription}
                  onChange={(e) => setJobDescription(e.target.value)}
                />
              </div>
            </div>

            {/* ACTION TO GENERATE */}
            <div style={{ textAlign: 'center' }}>
              <button
                onClick={handleGenerateResume}
                disabled={isGenerating || !profileText.trim() || !jobDescription.trim()}
                className="btn btn-primary"
                style={{ maxWidth: '300px', fontSize: '1rem', padding: '0.9rem 1.5rem' }}
              >
                {isGenerating ? 'Tailoring with Gemini AI...' : 'Generate Tailored Resume'}
              </button>
            </div>

            {/* SKELETON DISPLAY WHILE GENERATING */}
            {isGenerating && (
              <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                <div style={{ height: '20px', background: 'rgba(255,255,255,0.05)', borderRadius: '4px', width: '30%' }}></div>
                <div style={{ height: '100px', background: 'rgba(255,255,255,0.05)', borderRadius: '8px' }}></div>
                <div style={{ height: '20px', background: 'rgba(255,255,255,0.05)', borderRadius: '4px', width: '20%' }}></div>
                <div style={{ height: '200px', background: 'rgba(255,255,255,0.05)', borderRadius: '8px' }}></div>
              </div>
            )}

            {/* TAILORED RESUME OUTPUT & CONTROLS */}
            {resumeText && (
              <div className="card output-card">
                <div className="card-title">
                  <span>Tailored Resume (Editable)</span>
                  <span style={{ fontSize: '0.8rem', fontWeight: 'normal', color: 'var(--text-secondary)' }}>
                    Feel free to proofread and make manual edits below
                  </span>
                </div>

                <textarea
                  className="form-control resume-textarea"
                  value={resumeText}
                  onChange={(e) => setResumeText(e.target.value)}
                  placeholder="Your tailored resume text will appear here. Edit it directly."
                />

                {/* FORMATTED PREVIEW — matches the exported PDF */}
                <div className="resume-preview-wrap">
                  <div className="resume-preview-label">Formatted preview — exactly what your PDF / print will look like</div>
                  <div className="resume-preview">{renderResume(resumeText)}</div>
                </div>

                {/* TAILORING NOTES */}
                {tailoringNotes.length > 0 && (
                  <div className="notes-container">
                    <div className="notes-title">Tailoring Adjustments (Gemini Focus)</div>
                    <ul className="notes-list">
                      {tailoringNotes.map((note, index) => (
                        <li key={index}>{note}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* NAME YOUR SAVE */}
                <div className="save-row">
                  <label className="save-row-label" htmlFor="resume-title">
                    Resume title — labels this resume in “My Saved Resumes” (optional)
                  </label>
                  <input
                    id="resume-title"
                    type="text"
                    className="form-control"
                    placeholder="e.g. Data Analyst — Acme Corp"
                    value={saveTitle}
                    onChange={(e) => setSaveTitle(e.target.value)}
                  />
                </div>

                {/* CONTROL BUTTONS */}
                <div className="editor-actions">
                  <button
                    onClick={handleAtsCheck}
                    disabled={isAtsChecking}
                    className="btn btn-secondary"
                  >
                    {isAtsChecking ? 'Analyzing Keywords...' : '🔍 Check ATS Readiness'}
                  </button>

                  <button
                    onClick={handleSaveResume}
                    disabled={isSaving}
                    className="btn btn-secondary"
                  >
                    {isSaving ? 'Saving...' : '💾 Save Resume'}
                  </button>

                  <button
                    onClick={handleExportPdf}
                    className="btn btn-primary"
                  >
                    📄 Export to PDF / Print
                  </button>
                </div>

                {/* ATS ANALYSIS DASHBOARD */}
                {atsResult.score !== null && (
                  <div className="ats-dashboard">
                    <div className="ats-summary">
                      <div className={`ats-score-circle ${getScoreColorClass(atsResult.score)}`}>
                        {atsResult.score}%
                      </div>
                      <div className="ats-verdict-box">
                        <div className="ats-verdict-title" style={{ color: atsResult.score >= 80 ? 'var(--mint)' : atsResult.score >= 50 ? '#F59E0B' : '#EF4444' }}>
                          ATS Keyword Optimization
                        </div>
                        <div className="ats-verdict-desc">
                          {atsResult.verdict}
                        </div>
                      </div>
                    </div>

                    {/* KEYWORD CHIPS */}
                    {(atsResult.matched.length > 0 || atsResult.missing.length > 0) && (
                      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem', marginTop: '0.5rem' }}>
                        {/* MATCHED */}
                        <div className="keyword-chips-section">
                          <div className="keyword-category-title">Matched Keywords ({atsResult.matched.length})</div>
                          <div className="chips-container">
                            {atsResult.matched.length === 0 ? (
                              <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>None matched yet</span>
                            ) : (
                              atsResult.matched.map((kw, i) => (
                                <span key={i} className="chip chip-matched">{kw}</span>
                              ))
                            )}
                          </div>
                        </div>

                        {/* MISSING */}
                        <div className="keyword-chips-section">
                          <div className="keyword-category-title">Missing Core Keywords ({atsResult.missing.length})</div>
                          <div className="chips-container">
                            {atsResult.missing.length === 0 ? (
                              <span style={{ fontSize: '0.8rem', color: 'var(--mint)' }}>No missing core keywords!</span>
                            ) : (
                              atsResult.missing.map((kw, i) => (
                                <span key={i} className="chip chip-missing">{kw}</span>
                              ))
                            )}
                          </div>
                        </div>
                      </div>
                    )}

                    {atsResult.score < 80 && atsResult.missing.length > 0 && (
                      <div className="ats-tips">
                        <div className="ats-tips-title">How to raise your score</div>
                        <ol>
                          <li>Weave the missing keywords above into your Profile or resume text — only where they are genuinely true for you.</li>
                          <li>Match the job's exact wording (e.g. write "Analyst" if the description says "Analyst").</li>
                          <li>Edit the resume directly above, then click "Check ATS Readiness" again — or regenerate.</li>
                          <li>Paste the full job description, not just the title — a one-line JD yields very few keywords.</li>
                        </ol>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </section>
        </main>
      </div>
    </>
  );
}

export default App;